<?php if (isset($component)) { $__componentOriginaldc00e1a8e8c0f90d59470d5b15e40fcd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldc00e1a8e8c0f90d59470d5b15e40fcd = $attributes; } ?>
<?php $component = App\View\Components\RetailerLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('retailer-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\RetailerLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container mx-auto py-8">
        <h1 class="text-3xl py-4 border-b mb-10">Edit Product</h1>

        <!-- Display Validation Errors -->
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <!-- Form for editing the product -->
        <form action="<?php echo e(route('retailer.manage-product.update', ['productID' => $product->productID])); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <!-- Product details inputs -->
            <div class="mb-4">
                <label for="productName" class="block text-gray-700 text-sm font-bold mb-2">Product Name:</label>
                <input type="text" id="productName" name="productName" value="<?php echo e(old('productName', $product->productName)); ?>" class="form-input w-full">
            </div>

            <div class="mb-4">
                <label for="productDescription" class="block text-gray-700 text-sm font-bold mb-2">Product Description:</label>
                <textarea id="productDescription" name="productDescription" rows="4" class="form-textarea w-full"><?php echo e(old('productDescription', $product->productDescription)); ?></textarea>
            </div>

            <div class="mb-4">
                <label for="retailer_price" class="block text-gray-700 text-sm font-bold mb-2">Retailer's Price (₱):</label>
                <input type="number" id="retailer_price" name="retailer_price" value="<?php echo e(old('retailer_price', $retailerProduct->retailer_price ?? $product->productPrice)); ?>" class="form-input w-full">
            </div>

            <div class="mb-4">
                <label for="productImage" class="block text-gray-700 text-sm font-bold mb-2">Product Image:</label>
                <?php if($product->productImage): ?>
                    <img src="<?php echo e(asset('storage/' . $product->productImage)); ?>" alt="Product Image" class="w-64 mb-4">
                <?php else: ?>
                    <p>No image available</p>
                <?php endif; ?>
                <input type="file" id="productImage" name="productImage" class="form-input w-full">
            </div>

            <div class="mb-4">
                <label for="AvailableStocks" class="block text-gray-700 text-sm font-bold mb-2">Available Stocks:</label>
                <input type="number" id="AvailableStocks" name="AvailableStocks" value="<?php echo e(old('AvailableStocks', $product->AvailableStocks)); ?>" class="form-input w-full">
            </div>

            <div class="mb-4">
                <label for="categoryID" class="block text-gray-700 text-sm font-bold mb-2">Category:</label>
                <select id="categoryID" name="categoryID" class="form-select w-full">
                    <option value="">Select Category</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->categoryID); ?>" <?php echo e(old('categoryID', $product->categoryID) == $category->categoryID ? 'selected' : ''); ?>><?php echo e($category->categoryName); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="mb-4">
                <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">Update Product</button>
                <a href="<?php echo e(route('retailer.manage-product')); ?>" class="ml-4 inline-block bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-2 px-4 rounded">Cancel</a>
            </div>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldc00e1a8e8c0f90d59470d5b15e40fcd)): ?>
<?php $attributes = $__attributesOriginaldc00e1a8e8c0f90d59470d5b15e40fcd; ?>
<?php unset($__attributesOriginaldc00e1a8e8c0f90d59470d5b15e40fcd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldc00e1a8e8c0f90d59470d5b15e40fcd)): ?>
<?php $component = $__componentOriginaldc00e1a8e8c0f90d59470d5b15e40fcd; ?>
<?php unset($__componentOriginaldc00e1a8e8c0f90d59470d5b15e40fcd); ?>
<?php endif; ?>
<?php /**PATH C:\Users\ADMIN\Desktop\SIA\Activity4\resources\views/retailer/edit.blade.php ENDPATH**/ ?>