<?php if (isset($component)) { $__componentOriginaldc00e1a8e8c0f90d59470d5b15e40fcd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldc00e1a8e8c0f90d59470d5b15e40fcd = $attributes; } ?>
<?php $component = App\View\Components\RetailerLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('retailer-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\RetailerLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container">
        <h1>My Orders</h1>
        <table class="table">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Quantity</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($order->product->productName); ?></td>
                    <td><?php echo e($order->quantity); ?></td>
                    <td><?php echo e($order->created_at->format('Y-m-d')); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldc00e1a8e8c0f90d59470d5b15e40fcd)): ?>
<?php $attributes = $__attributesOriginaldc00e1a8e8c0f90d59470d5b15e40fcd; ?>
<?php unset($__attributesOriginaldc00e1a8e8c0f90d59470d5b15e40fcd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldc00e1a8e8c0f90d59470d5b15e40fcd)): ?>
<?php $component = $__componentOriginaldc00e1a8e8c0f90d59470d5b15e40fcd; ?>
<?php unset($__componentOriginaldc00e1a8e8c0f90d59470d5b15e40fcd); ?>
<?php endif; ?><?php /**PATH C:\Users\ADMIN\Desktop\SIA\Activity4\resources\views/retailer/orders.blade.php ENDPATH**/ ?>