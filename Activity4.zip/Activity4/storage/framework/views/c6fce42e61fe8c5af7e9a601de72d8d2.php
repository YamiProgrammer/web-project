<?php if (isset($component)) { $__componentOriginaldc00e1a8e8c0f90d59470d5b15e40fcd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldc00e1a8e8c0f90d59470d5b15e40fcd = $attributes; } ?>
<?php $component = App\View\Components\RetailerLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('retailer-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\RetailerLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<div class="container p-6">
        <h1 class="pb-6">Retailer Homepage</h1>
        
        <div class="grid grid-cols-1 md:grid-cols-3">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="relative flex w-96 flex-col rounded-xl bg-white bg-clip-border text-gray-700 shadow-md">

                    <div class="relative mx-4 mt-4 h-auto overflow-hidden rounded-xl bg-white bg-clip-border text-gray-700">
                        <img src="<?php echo e(asset('storage/' . $product->productImage)); ?>" class="card-img-top" alt="<?php echo e($product->productName); ?>">
                        <div class="p-6">
                            <div class="mb-2 items-center">
                                <p class="block font-sans text-base font-medium leading-relaxed text-blue-gray-900 antialiased"><?php echo e($product->productName); ?></h5>
                                <p class="block font-sans text-base font-medium leading-relaxed text-blue-gray-900 antialiased">
                                <?php if($product->retailerProduct): ?>
                                        <p class="">Price: <?php echo e($product->retailerProduct->retailer_price); ?>₱</p>
                                    <?php endif; ?>
                                </p>
                            </div>
                            <p class="block font-sans text-sm font-normal leading-normal text-gray-700 antialiased opacity-75"><?php echo e($product->productDescription); ?></p>
                            <p class="block font-sans text-base font-medium leading-relaxed text-blue-gray-900 my-2 antialiased">
                                <?php $__currentLoopData = $product->orders ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div>Available Stocks: <?php echo e($order->quantity); ?></div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </p>
                            <form action="<?php echo e(route('retailer.orders.store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="productID" value="<?php echo e($product->productID); ?>">
                                <div class="form-group">
                                    <input type="number" name="quantity" class="form-control block w-full select-none rounded-lg bg-blue-gray-900/10 py-3 px-6 text-center align-middle font-sans text-xs font-bold uppercase text-blue-gray-900 transition-all hover:scale-105" id="quantity" placeholder="Quantity" min="1" max="<?php echo e($product->AvailableStocks); ?>" required>
                                </div>
                                <button type="submit" class="block w-full select-none rounded-lg bg-gray py-3 px-6 text-center align-middle font-sans text-xs font-bold uppercase text-blue-gray-900 transition-all hover:scale-105 focus:scale-105 focus:opacity-[0.85] active:scale-100 active:opacity-[0.85] disabled:pointer-events-none disabled:opacity-50 disabled:shadow-none">Order</button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldc00e1a8e8c0f90d59470d5b15e40fcd)): ?>
<?php $attributes = $__attributesOriginaldc00e1a8e8c0f90d59470d5b15e40fcd; ?>
<?php unset($__attributesOriginaldc00e1a8e8c0f90d59470d5b15e40fcd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldc00e1a8e8c0f90d59470d5b15e40fcd)): ?>
<?php $component = $__componentOriginaldc00e1a8e8c0f90d59470d5b15e40fcd; ?>
<?php unset($__componentOriginaldc00e1a8e8c0f90d59470d5b15e40fcd); ?>
<?php endif; ?><?php /**PATH C:\Users\ADMIN\Desktop\SIA\Activity4\resources\views/retailer/home.blade.php ENDPATH**/ ?>