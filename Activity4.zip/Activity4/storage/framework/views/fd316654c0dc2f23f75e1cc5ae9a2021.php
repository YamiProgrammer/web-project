<?php if (isset($component)) { $__componentOriginaldbebf91c3e6ef1cf5f328534d0527660 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldbebf91c3e6ef1cf5f328534d0527660 = $attributes; } ?>
<?php $component = App\View\Components\SupplierLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('supplier-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SupplierLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<div class="container mx-auto py-8">
    <h1 class="text-3xl py-3 border-b mb-8">Edit Product</h1>

    <form action="<?php echo e(route('supplier.manage-product.update', ['productID' => $product->productID])); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="form-group mb-4">
            <label for="productName">Product Name</label>
            <input type="text" name="productName" id="productName" class="form-control w-full" value="<?php echo e($product->productName); ?>" required>
        </div>

        <div class="form-group mb-4">
            <label for="productDescription">Product Description</label>
            <textarea name="productDescription" id="productDescription" class="form-control w-full" rows="3" required><?php echo e($product->productDescription); ?></textarea>
        </div>

        <div class="form-group mb-4">
            <label for="productPrice">Product Price</label>
            <input type="number" name="productPrice" id="productPrice" class="form-control w-full" step="0.01" value="<?php echo e($product->productPrice); ?>" required>
        </div>

        <div class="form-group mb-4">
            <label for="productImage">Product Image</label>
            <input type="file" name="productImage" id="productImage" class="form-control-file" accept="image/*">
            <?php if($product->productImage): ?>
                <img src="<?php echo e(asset('storage/' . $product->productImage)); ?>" alt="<?php echo e($product->productName); ?>" style="max-width: 100px; max-height: 100px;">
            <?php else: ?>
                No Image
            <?php endif; ?>
        </div>

        <div class="form-group mb-4">
            <label for="AvailableStocks">Available Stocks</label>
            <input type="number" name="AvailableStocks" id="AvailableStocks" class="form-control w-full" value="<?php echo e($product->AvailableStocks); ?>" required>
        </div>

        <div class="form-group mb-4">
            <label for="categoryID">Category</label>
            <select name="categoryID" id="categoryID" class="form-control" required>
                <option value="" disabled selected>Select a category</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->categoryID); ?>"><?php echo e($category->categoryName); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="buttons flex justify-end">
            <button type="submit" class="btn btn-primary border border-indigo-500 p-1 px-4 font-semibold cursor-pointer text-gray-200 ml-2 bg-indigo-500">Update Product</button>    
        </div>
        
    </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldbebf91c3e6ef1cf5f328534d0527660)): ?>
<?php $attributes = $__attributesOriginaldbebf91c3e6ef1cf5f328534d0527660; ?>
<?php unset($__attributesOriginaldbebf91c3e6ef1cf5f328534d0527660); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldbebf91c3e6ef1cf5f328534d0527660)): ?>
<?php $component = $__componentOriginaldbebf91c3e6ef1cf5f328534d0527660; ?>
<?php unset($__componentOriginaldbebf91c3e6ef1cf5f328534d0527660); ?>
<?php endif; ?><?php /**PATH C:\Users\ADMIN\Desktop\SIA\Activity4\resources\views/supplier/edit.blade.php ENDPATH**/ ?>